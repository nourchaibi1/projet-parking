#include <gtk/gtk.h>


void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton15_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiofemme_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiomale_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button45_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button46_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton11_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton12_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton15_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_inscription_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouthadil_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button37_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_login_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_loginbtn_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_deconnexion_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_suprimer_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button51_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button52_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton16_activate              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button32_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton16_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button67_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button47_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_calculer_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button69_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_gestion_de_compte_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button48_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button71_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button70_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
