#ifndef SERVICE_H_INCLUDED
#define SERVICE_H_INCLUDED

#include <stdio.h>

typedef struct {
    char idclient[50];
    char id_service[50];
    char type[50];
    char prix[50];        
    char paiement[50];
    char duree[50];
    char jour[50];
    char mois[50];
    char annee[50];

} service;




#endif  
